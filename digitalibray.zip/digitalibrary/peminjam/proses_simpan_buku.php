<?php 
ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);
// koneksi database
include '../koneksi.php';
 
// menangkap data yang di kirim dari form
$Judul = $_POST['Judul'];
$Penulis = $_POST['Penulis'];
$Penerbit = $_POST['Penerbit'];
$TahunTerbit = $_POST['Tahun_terbit'];

 
// menginput data ke database
mysqli_query($koneksi,"INSERT INTO `buku` VALUES (NULL,'$Judul','$Penulis','$Penerbit','$TahunTerbit')");
// if (!$koneksi -> query("INSERT INTO `buku` VALUES (NULL,'$Judul','$Penulis','$Penerbit','$TahunTerbit')")) {
//     echo("Error description: " . $koneksi -> error);
//     }
    
// mengalihkan halaman kembali ke index.php
header("location:buku.php?pesan=simpan");
 
?>