<?php 
// koneksi database
ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);
include '../koneksi.php';
 
// menangkap data yang di kirim dari form
$UserID = $_POST['UserID'];
$BukuID = $_POST['BukuID'];
$TanggalPeminjaman = $_POST['TanggalPeminjaman'];
$TanggalPengembalian = $_POST['TanggalPengembalian'];
$StatusPeminjaman = $_POST['StatusPeminjaman'];

// menginput data ke database
// mysqli_query($koneksi,"insert into peminjaman values(0,'$UserID' ,'$BukuID', '$TanggalPeminjaman', '$TanggalPengembalian', '$StatusPeminjaman')");
 
if (!$koneksi -> query("insert into peminjaman values(0,'$UserID' ,'$BukuID', '$TanggalPeminjaman', '$TanggalPengembalian', '$StatusPeminjaman')")) 
{
    echo("Error description: " . $koneksi -> error);
}
// mengalihkan halaman kembali ke kategori.php
header("location:peminjaman.php?pesan=simpan");
 
?>