<?php 
// koneksi database
include '../koneksi.php';
 
// menangkap data yang di kirim dari form
$Username = $_POST['Username'];
$Password = md5($_POST['Password']);
$Email = $_POST['Email'];
$NamaLengkap = $_POST['NamaLengkap'];
$Alamat = $_POST['Alamat'];

 
// menginput data ke database
//mysqli_query($koneksi,"INSERT INTO `user' VALUES (NULL, '$Username','$Password','$Email','$NamaLengkap','$Alamat'.'2')");
mysqli_query($koneksi,"INSERT INTO `user`(`UserID`, `Username`, `Password`, `Email`, `NamaLengkap`, `Alamat`, `Level`) VALUES (0,'$Username','$Password','$Email','$NamaLengkap','$Alamat','1')");

// mengalihkan halaman kembali ke index.php
header("location:users.php?pesan=simpan");
 
?>

